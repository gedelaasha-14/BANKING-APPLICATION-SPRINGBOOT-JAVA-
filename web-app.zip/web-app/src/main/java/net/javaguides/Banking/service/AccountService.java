package net.javaguides.Banking.service;
import net.javaguides.Banking.entity.Account;
import java.util.List;

public interface AccountService {
   Account createAccount(Account account);//creation of account

    Account getAccountById(Long id);//retrieve the account details based on id

    void deposit(Long accountId, Double amount); // Method for deposit//deposit money into the account
   Account withdraw(Long id, double amount);//withdraw money from the account
    List<Account> getAllAccounts();   // Method signature to get all accounts
   void deleteAccount(Long id);//delete the account
}