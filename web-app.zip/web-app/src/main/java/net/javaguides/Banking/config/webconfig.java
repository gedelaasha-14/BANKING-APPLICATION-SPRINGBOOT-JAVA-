package net.javaguides.Banking.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
@EnableWebMvc
public class webconfig implements WebMvcConfigurer {

    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        // Serve HTML, JS, and CSS files from the static folder
        registry.addResourceHandler("/**")
                .addResourceLocations("classpath:/static/");
    }
}

//WebMvcConfigurer is an interface in Spring Framework that allows you to customize the configuration of Spring MVC (Model-View-Controller). When you implement this interface, you can override its methods to modify how Spring MVC works, such as how it handles static resources, configures view resolvers, or sets up interceptors.

