package net.javaguides.Banking.service.imp;

import net.javaguides.Banking.entity.Account;
import net.javaguides.Banking.repository.AccountRepository;
import net.javaguides.Banking.service.AccountService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AccountServiceImp implements AccountService {

    // Dependency injection for AccountRepository
    private final AccountRepository accountRepository;

    // Constructor-based injection of AccountRepository
    public AccountServiceImp(AccountRepository accountRepository) {
        this.accountRepository = accountRepository;
        // AccountRepository: This is an interface for data access operations.
        // The constructor injects the AccountRepository dependency, ensuring
        // that this service class has access to the necessary repository methods.
    }

    // Method to create a new account
    public Account createAccount(Account account) {
        // Check if account ID already exists in the repository
        if (accountRepository.existsById(account.getId())) {
            // If the account ID exists, throw an exception to prevent duplicate accounts
            throw new RuntimeException("Account with ID " + account.getId() + " already exists.");
        }
        // If the account ID does not exist, save the new account to the repository
        return accountRepository.save(account);
    }

    // Method to get an account by its ID
    @Override
    public Account getAccountById(Long id) {
        // Attempt to find the account by ID
        return accountRepository.findById(id)
                // If the account is not found, throw an exception
                .orElseThrow(() -> new RuntimeException("Account not found"));
    }

    // Method to deposit money into an account
    @Override
    public void deposit(Long id, Double amount) {
        // Attempt to find the account by ID
        Account account = accountRepository.findById(id)
                // If the account is not found, throw an exception
                .orElseThrow(() -> new RuntimeException("Account not found with ID: " + id));

        // Update the account's balance by adding the deposit amount
        account.setBalance(account.getBalance() + amount);
        // Save the updated account back to the repository
        accountRepository.save(account);
    }

    // Method to withdraw money from an account
    @Override
    public Account withdraw(Long id, double amount) {
        // Attempt to find the account by ID
        Account account = accountRepository.findById(id)
                // If the account is not found, throw an exception
                .orElseThrow(() -> new RuntimeException("Account not found"));

        // Check if the account has sufficient balance for the withdrawal
        if (account.getBalance() < amount) {
            // If the balance is insufficient, throw an exception
            throw new RuntimeException("Insufficient balance");
        }

        // Update the account's balance by subtracting the withdrawal amount
        account.setBalance(account.getBalance() - amount);
        // Save the updated account back to the repository and return it
        return accountRepository.save(account);
    }

    // Method to retrieve all accounts
    @Override
    public List<Account> getAllAccounts() {
        // Return the list of all accounts from the repository
        return accountRepository.findAll();
    }

    // Method to delete an account by its ID
    @Override
    public void deleteAccount(Long id) {
        // Attempt to find the account by ID
        Account account = accountRepository.findById(id)
                // If the account is not found, throw an exception
                .orElseThrow(() -> new RuntimeException("Account not found"));
        // Delete the account from the repository
        accountRepository.delete(account);
    }
}
