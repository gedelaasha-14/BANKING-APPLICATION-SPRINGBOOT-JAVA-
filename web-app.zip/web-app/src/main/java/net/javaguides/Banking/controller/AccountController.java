package net.javaguides.Banking.controller;

// Import necessary classes and annotations for the controller
import net.javaguides.Banking.entity.Account;
import net.javaguides.Banking.service.AccountService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

// Annotates this class as a REST controller and sets the base URL for all endpoints
@RestController
@RequestMapping("/api/accounts")
public class AccountController {

    // Dependency injection for AccountService
    private final AccountService accountService;

    // Constructor-based injection of AccountService
    public AccountController(AccountService accountService) {
        this.accountService = accountService;
    }

    // Endpoint to create a new account
    @PostMapping("/create")
    public ResponseEntity<?> createAccount(@RequestBody Account account) {
        try {
            // Calls the service method to create an account
            Account createdAccount = accountService.createAccount(account);
            // Returns the created account with a HTTP status of 201 (Created)
            return new ResponseEntity<>(createdAccount, HttpStatus.CREATED);
        } catch (RuntimeException e) {
            // Returns an error message with a HTTP status of 400 (Bad Request)
            return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }

    // Endpoint to deposit money into an account
    @PostMapping("/{accountId}/deposit")
    public ResponseEntity<String> deposit(@PathVariable Long accountId, @RequestParam Double amount) {
        try {
            // Calls the service method to deposit money into the account
            accountService.deposit(accountId, amount);
            // Returns a success message with a HTTP status of 200 (OK)
            return ResponseEntity.ok("Deposit successful");
        } catch (RuntimeException e) {
            // Returns an error message with a HTTP status of 404 (Not Found)
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        }
    }

    // Endpoint to withdraw money from an account
    @PutMapping("/{id}/withdraw")
    public ResponseEntity<String> withdraw(@PathVariable Long id, @RequestBody Map<String, Double> requestBody) {
        try {
            // Extracts the amount from the request body
            double amount = requestBody.get("amount");
            // Calls the service method to withdraw money from the account
            accountService.withdraw(id, amount);
            // Returns a success message with a HTTP status of 200 (OK)
            return ResponseEntity.ok("Withdrawal successful");
        } catch (RuntimeException e) {
            // Returns an error message with a HTTP status of 400 (Bad Request)
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
        }
    }

    // Endpoint to get a list of all accounts
    @GetMapping("/accounts")
    public ResponseEntity<List<Account>> getAllAccounts() {
        // Calls the service method to retrieve all accounts
        List<Account> accounts = accountService.getAllAccounts();

        // If no accounts are found, returns a HTTP status of 204 (No Content)
        if (accounts.isEmpty()) {
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        }

        // Returns the list of accounts with a HTTP status of 200 (OK)
        return new ResponseEntity<>(accounts, HttpStatus.OK);
    }

    // Endpoint to delete an account by ID
    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteAccount(@PathVariable Long id) {
        try {
            // Calls the service method to delete the account
            accountService.deleteAccount(id);
            // Returns a success message with a HTTP status of 200 (OK)
            return ResponseEntity.ok("Account deleted successfully");
        } catch (RuntimeException e) {
            // Returns an error message with a HTTP status of 404 (Not Found)
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        }
    }

}
