package net.javaguides.Banking.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "accounts")
public class Account
{
    @Id //specifies the primary key of ane entity
    @Column(name = "id")//@column specifies the mapping between a java class attribute and database table column
    private Long id;  // User-entered ID, no auto-generation

    @Column(name = "name")
    private String name;

    @Column(name = "gender")
    private String gender;

    @Column(name = "balance")
    private double balance;

    // Getters and Setters
}
